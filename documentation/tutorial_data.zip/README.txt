The contents of this file was created with the drEEM toolbox for Matlab

FOLDER INFORMATION
The folder 'EEMs contains fluorescence EEMs with emission wavelengths as rows and excitation wavelengths as columns.
If blank EEMs were subtracted by the toolbox (and only then), these will be provided as an additional file, same filename with an '_blank' added before the '.csv'.
The folder 'absorbance spectra contains wavelengths in column 1 and absorbance data in column 2. The unit is specified in column 2 header.

PROCESSING / STATUS INFORMATION
Any processing of the data done by the toolbox is documented in the file 'dataset_history.csv'
If scatter was removed by the toolbox, the settings for the removal are stored in the file 'dataset_scatterRemovalParameters.csv'
The general status of the dataset (signal calibration, spectral correction, and more) is provided in the file 'dataset_status.csv'

ENVIRONMENTAL / OPTICAL METADATA
The DOM-specific optical indicies, peaks, and CDOM slopes are provided in the file 'dataset_opticalIndiciesAndPeakIntensities.csv'
If provided, other metadata is stored in the file 'dataset_metadata.csv'

OTHER
For convenience of Matlab users, the dataset is also provided as .mat file 'dataset_dreem.mat'
Information regarding the version of Matlab used and the drEEM toolbox is stored in 'drEEM_versionInformation.csv'

THIS IS THE END OF THIS FILE.